This directory contains a solution and project files that can be used to
build xa and the various tools in the misc directory with the free version
of Microsoft Visual C++ 2005 (AKA Visual Studio 2005 Express).  This compiler
and IDE can be dowloaded free from

http://msdn.microsoft.com/vstudio/express/downloads/default.aspx

Just run visual studio and load the solution called "vstudio.sln"
